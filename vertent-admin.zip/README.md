# Vertente Admin

Painel administrativo web do Vertente, para cadastrar/gerenciar
usuários e terrenos usados pelo app mobile. Consome o backend
`Vertent-BackEnd` já existente (hospedado no Render) através das rotas
`/admin/*`.

## Rodando localmente

```
npm install
cp .env.example .env
# edite .env e aponte VITE_API_URL para o backend (local ou Render)
npm run dev
```

Abre em `http://localhost:5175`.

## Antes do primeiro uso

Este painel **não tem cadastro público de administrador**. Antes de
logar aqui, crie o primeiro admin direto no backend (veja o README do
`Vertent-BackEnd`, seção "Painel Administrativo"):

```
node src/scripts/createAdmin.cjs "Seu Nome" seu@email.com "senhaForte123"
```

## Deploy na Vercel

1. Suba este projeto (`vertent-admin`) como um repositório separado no
   GitHub.
2. Na Vercel, importe o repositório (framework preset: **Vite**).
3. Em *Environment Variables*, adicione:
   ```
   VITE_API_URL=https://vertent-backend-4.onrender.com
   ```
   (ou a URL do seu backend no Render)
4. Deploy. Build command `npm run build`, output `dist` (padrão do
   preset Vite - não precisa mexer).

## Estrutura

- `src/pages` - telas (Login, Dashboard, Terrenos, Novo Terreno,
  Editar Terreno, Usuários, Configurações).
- `src/components` - Layout (sidebar/header), dropzone de GLB, preview
  3D (`@react-three/fiber`, mesmo padrão já usado no `vertent-web`),
  peças de UI reutilizáveis.
- `src/lib/api.ts` - cliente HTTP único, injeta o token JWT do admin e
  trata upload multipart com barra de progresso.
- `src/context/AuthContext.tsx` - sessão do admin (token em
  `localStorage`, restaurada ao recarregar a página).

## Identidade visual

Paleta reaproveitada do que já existe no app mobile Vertente
(`#2C6E49` é a mesma cor usada no título/botão de login do app) mais
tons de verde escuro/claro e fundo neutro. Tipografia: Space Grotesk
(títulos) + Inter (texto/tabelas). O único elemento decorativo é um
traço de curvas de nível (linhas topográficas), usado com moderação no
login e no topo da sidebar.
